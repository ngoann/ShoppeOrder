chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
   	chrome.tabs.executeScript(tabId, {
  	  code: `
        var changeInfo = "${changeInfo.status}"
        var _target_url = encodeURI("${localStorage.getItem('shopeeLink')}")
        var activeChecked = ${localStorage.getItem('activeCheckbox')}
        var validate = 1586908800000
        var today = new Date().getTime()
        var orderdNumber = localStorage.getItem('orderdNumber') || 0

        console.log("activeChecked:", activeChecked)
        console.log("today < validate:", today < validate)
        console.log("parseInt(orderdNumber) < 2:", parseInt(orderdNumber) < 2)

        if(changeInfo == 'complete') {
          if (activeChecked && today < validate && parseInt(orderdNumber) < 2) {
            if (location.href.includes('shopee.vn/checkout')) {
              findAndOrder()
            } else if (location.href.includes('shopee.vn/cart')) {
              findAndClickBuy()
            } else if (_target_url == location.href) {
              if (document.getElementsByClassName('YtgjXY').length) {
                document.getElementsByClassName('YtgjXY')[1].click()
              } else {
                setTimeout(function(){
                  location.href=_target_url
                }, 10000);
              }

            } else {
              setTimeout(function(){
                location.href=_target_url
              }, 10000);
            }
          }
        }

        function findAndClickBuy() {
          setTimeout(function() {
            if (document.getElementsByClassName('shopee-button-solid').length) {
              document.getElementsByClassName('shopee-button-solid')[0].click()
            } else {
              findAndClickBuy()
            }

            console.log("In cart: ", document.getElementsByClassName('shopee-button-solid').length)
          }, 1000)
        }

        function findAndOrder() {
          setTimeout(function() {
            if(document.getElementsByClassName('stardust-button').length) {
              if (orderdNumber < 2) {
                document.getElementsByClassName('stardust-button')[0].click()
                debugger
                localStorage.setItem('orderdNumber', parseInt(orderdNumber) + 1)
              }
            } else {
              findAndOrder()
            }

            console.log("In checkout: ", document.getElementsByClassName('stardust-button').length)
          }, 1000)
        }
  	  `
  	})
})
