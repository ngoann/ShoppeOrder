$('#shopeeLink').val().trim().length || $('#shopeeLink').val(localStorage.getItem('shopeeLink'))
$("#activeCheckbox").prop('checked', localStorage.getItem('activeCheckbox') == "true");


$('.btnSetup').click(function() {
  var shopeeLink = $('#shopeeLink').val()

  localStorage.setItem('shopeeLink', shopeeLink)

  chrome.tabs.create({url: shopeeLink, active: true});
})

$('#activeCheckbox').change(function() {
  localStorage.setItem('activeCheckbox', $(this).is(':checked'))
})
